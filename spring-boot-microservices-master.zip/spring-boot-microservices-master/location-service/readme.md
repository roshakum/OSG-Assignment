### Location service 

To get any public ip address location
```
mvn spring-boot:run
```
Browse to http://localhost:8088/ip/103.94.135.151 or any other public ip.
you will shown its Country, city name and region.
