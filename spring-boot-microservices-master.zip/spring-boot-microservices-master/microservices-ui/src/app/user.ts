export class User {
    id:Number;
    fname:string;
    lname:string;
}