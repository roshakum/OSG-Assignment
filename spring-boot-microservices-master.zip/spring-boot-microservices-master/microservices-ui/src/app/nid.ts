export class Nid {
    fname:string;
    lname:string;
    nid:string;
    ppid:string;
    birthdate:string;
    mobile:string;
}
