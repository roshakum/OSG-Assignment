"use strict";
exports.__esModule = true;
var Nid = /** @class */ (function () {
    function Nid() {
    }
    return Nid;
}());
exports.Nid = Nid;
