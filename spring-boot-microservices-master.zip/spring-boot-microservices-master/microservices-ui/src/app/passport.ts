export class Passport {
    fname:string;
    lname:string;
    email:string;
    nid:string;
    ppid:string;
    birthdate:string;
}
