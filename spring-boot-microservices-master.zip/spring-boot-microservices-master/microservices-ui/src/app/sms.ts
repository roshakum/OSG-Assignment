export class Sms {
    id:number;
    message:string;
    date:string;
}
