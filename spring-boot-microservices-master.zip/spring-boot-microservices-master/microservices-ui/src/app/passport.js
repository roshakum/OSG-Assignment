"use strict";
exports.__esModule = true;
var Passport = /** @class */ (function () {
    function Passport() {
    }
    return Passport;
}());
exports.Passport = Passport;
